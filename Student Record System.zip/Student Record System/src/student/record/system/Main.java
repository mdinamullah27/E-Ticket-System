
package student.record.system;

import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        Record.display();
        Scanner s = new Scanner(System.in);
        Login ss = new Login();
        ss.setPassword("InamKhan");
        ss.setUsername("InamKhan");
        String a = ss.getUsername();
        String b = ss.getUsername();
        int count = 1;
        int c = ss.Login(a, b, count);
        if (5 >= c) {
            Record[] MT = new Record[500];
            int i;
            for (i = 0; i < 500; i++) {
                
                    MT[i] = new Record();
                    MT[i].id = 0;
                
            }

            Record.User(MT);
        } else {
            System.out.println("you are Blocked");

        }

    }
}
