
package student.record.system;

import java.util.Scanner;


public class Record {
    int id;
    String name,sec;
    int batch;
    public static void display()
    {
        
    }
    public static void User(Record MT[])
    {
        System.out.println("1:Record\n"
                + "2:Record delete\n"
                + "3: Search\n"
                + "4: Exit");
        int n;
        Scanner s = new Scanner(System.in);
        n = s.nextInt();
        s.nextLine();
        switch (n) {
            case 1: {
                Record.record(MT);
                break;
            }
            case 2:
               Record.delete(MT);
                break;
            case 3:
                 Record.Search(MT);
               
                break;
            case 4:
                System.exit(n);

            default:
                Record.User(MT);
        }
    }
    public static void record(Record MT[])
    {
        Scanner s = new Scanner(System.in);
        
        for (int i = 0; i < 500; i++) {
            if(MT[i].id==0)
            {
               
                System.out.print("Enter Your Name :");
                MT[i].name=s.nextLine();
                System.out.println("");
                 
                System.out.print("Enter Your ID :");
                MT[i].id=s.nextInt();
                System.out.println("");
                 s.nextLine();
                System.out.print("Enter Your Section :");
                MT[i].sec=s.nextLine();
                System.out.println("");
                System.out.print("Enter Your Batch :");
                MT[i].batch=s.nextInt();
                System.out.println("");
                break;
                            
            }
            
         
        }
        System.out.println("Your information are recorted");
        Record.User(MT);
    }
    public static void delete(Record MT[])
    {
        Scanner s = new Scanner(System.in);
         System.out.print("Enter Your id :");
         int id=s.nextInt();
         for (int i = 0; i < 500; i++) {
            if(MT[i].id==id)
            {
                MT[i].name="";
                MT[i].id=0;
                MT[i].sec="";
                MT[i].batch=0;
                System.out.println("Your record are deleted.");
                
            }
            
            
         } 
         Record.User(MT);
    }
    public static void Search(Record MT[])
    {
        Scanner s = new Scanner(System.in);
           System.out.print("Enter Your id :");
         int id=s.nextInt();
         for (int i = 0; i < 500; i++) {
            if(MT[i].id==id)
            {
                System.out.printf("Name: %s\n",MT[i].name);
                System.out.printf("ID: %d\n",MT[i].id);
                System.out.printf("Sec: %s\n",MT[i].sec);
                System.out.printf("Batch: %d\n",MT[i].batch);
                
            }
            
            
         } 
         Record.User(MT);
    }
}
